const form = document.getElementById('form');
const name = document.getElementById('name');
const username = document.getElementById('user_name');
const phone = document.getElementById('phone_number');
const email = document.getElementById('email');
const password = document.getElementById('pass');
const password2 = document.getElementById('cpass');

const inputs = document.querySelectorAll(".input");

var resultname = false;
var resultusername = false;
var resultphone = false;
var resultemail = false;
var resultpass = false;
var resultcpass = false;

function addcl(){
	let parent = this.parentNode.parentNode;
	parent.classList.add("focus");
}

function remcl(){
	let parent = this.parentNode.parentNode;
	if(this.value == ""){
		parent.classList.remove("focus");
	}
}


inputs.forEach(input => {
	input.addEventListener("focus", addcl);
	input.addEventListener("blur", remcl);
});

// form.addEventListener('submit', e => {
// 	e.preventDefault();
// 	checkInputs();
// 	console.log(result);
// 	if(result==true)
// 	{
// 		insertdata();
// 	}
// });

function checkInputs() {
	// trim to remove the whitespaces
	const usernameValue = username.value.trim();
	const namevalue = name.value.trim();
	const emailValue = email.value.trim();
	const passwordValue = password.value.trim();
	const password2Value = password2.value.trim();
	
	if(usernameValue === '') {
		setErrorFor(user_name, 'Username cannot be blank');
		resultusername = false;
	} else {
		setSuccessFor(user_name);
		resultusername = true;
	}

	if(namevalue === '') {
		setErrorFor(name, 'Name cannot be blank');
		resultname = false;
	} else {
		setSuccessFor(name);
		resultname = true;
	}

	var phoneno =  /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{6})$/;
  	if(phone.value.match(phoneno))
        {
			setSuccessFor(phone_number);
			resultphone = true;
        }
      else
        {
			setErrorFor(phone_number, 'Invalid Phone number !');
			resultphone = false;
        }
		
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(emailValue == '')
	{
		setErrorFor(email, 'Email cannot be blank');
		resultemail = false;
	}
	else if(emailValue.match(mailformat)) {
		setSuccessFor(email);
		resultemail = true;
	} else {
		setErrorFor(email, 'Invalid Email');
		resultemail = false;
	}
	
	if(passwordValue === '') {
		setErrorFor(pass, 'Password cannot be blank');
		resultpass = false;
	} else if( passwordValue.length < 8){
		setErrorFor(pass, 'Password should be grater then 8!');
		resultpass = false;
	}else{
		setSuccessFor(pass);
		resultpass = true;
	}
	
	if(password2Value === '') {
		setErrorFor(cpass, 'Password cannot be blank');
		resultcpass = false;
	} else if(passwordValue !== password2Value) {
		setErrorFor(cpass, 'Password does not match');
		resultcpass = false;
	} else{
		setSuccessFor(cpass);
		resultcpass = true;
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	


