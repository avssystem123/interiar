const form = document.getElementById('form');
const name = document.getElementById('name');
const username = document.getElementById('user_name');
const phone = document.getElementById('phone_number');
const email = document.getElementById('email');
const password = document.getElementById('pass');
const password2 = document.getElementById('cpass');

const inputs = document.querySelectorAll(".input");
var result = false;

function addcl(){
	let parent = this.parentNode.parentNode;
	parent.classList.add("focus");
}

function remcl(){
	let parent = this.parentNode.parentNode;
	if(this.value == ""){
		parent.classList.remove("focus");
	}
}


inputs.forEach(input => {
	input.addEventListener("focus", addcl);
	input.addEventListener("blur", remcl);
});

// form.addEventListener('submit', e => {
// 	e.preventDefault();
// 	checkInputs();
// 	console.log(result);
// 	if(result==true)
// 	{
// 		insertdata();
// 	}
// });

function checkInputs() {
	// trim to remove the whitespaces
	const usernameValue = username.value.trim();
	const namevalue = name.value.trim();
	const emailValue = email.value.trim();
	const passwordValue = password.value.trim();
	const password2Value = password2.value.trim();
	
	if(usernameValue === '') {
		setErrorFor(user_name, 'Username cannot be blank');
		result = false;
	} else {
		setSuccessFor(user_name);
		result = true;
	}

	if(namevalue === '') {
		setErrorFor(name, 'Name cannot be blank');
		result = false;
	} else {
		setSuccessFor(name);
		result = true;
	}

	var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
  	if(phone.value.match(phoneno))
        {
			setSuccessFor(phone_number);
			result = true;
        }
      else
        {
			setErrorFor(phone_number, 'Invalid Phone number !');
			result = false;
        }
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	if(emailValue == '')
	{
		setErrorFor(email, 'Email cannot be blank');
		result = false;
	}
	else if(emailValue.match(mailformat)) {
		setSuccessFor(email);
		result = true;
	} else {
		setErrorFor(email, 'Invalid Email');
		result = false;
	}
	
	if(passwordValue === '') {
		setErrorFor(pass, 'Password cannot be blank');
		result = false;
	} else if( passwordValue.length < 8){
		setErrorFor(pass, 'Password should be grater then 8!');
		result = false;
	}else{
		setSuccessFor(pass);
		result = true;
	}
	
	if(password2Value === '') {
		setErrorFor(cpass, 'Password cannot be blank');
		result = false;
	} else if(passwordValue !== password2Value) {
		setErrorFor(cpass, 'Password does not match');
		result = false;
	} else{
		setSuccessFor(cpass);
		result = true;
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	


